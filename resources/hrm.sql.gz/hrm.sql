-- phpMyAdmin SQL Dump
-- version 2.8.2.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 21, 2006 at 11:34 AM
-- Server version: 4.1.19
-- PHP Version: 5.0.4
-- 
-- Database: `hrm`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `boundary_values`
-- 

CREATE TABLE `boundary_values` (
  `parameter` varchar(255) NOT NULL default '0',
  `min` varchar(30) default NULL,
  `max` varchar(30) default NULL,
  `min_included` enum('t','f') default 't',
  `max_included` enum('t','f') default 't',
  `standard` varchar(30) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='boundary values for numerical parameters';

-- 
-- Dumping data for table `boundary_values`
-- 

INSERT INTO `boundary_values` (`parameter`, `min`, `max`, `min_included`, `max_included`, `standard`) VALUES ('PinholeSize', '0', NULL, 'f', 't', NULL),
('RemoveBackgroundPercent', '0', '100', 'f', 't', NULL),
('BackgroundOffsetPercent', '0', '100', 't', 't', NULL),
('ExcitationWavelength', '0', NULL, 'f', 't', NULL),
('EmissionWavelength', '0', NULL, 'f', 't', NULL),
('CMount', '0.4', '1', 't', 't', '1'),
('TubeFactor', '1', '2', 't', 't', '1'),
('CCDCaptorSizeX', '1', '25000', 't', 't', NULL),
('CCDCaptorSizeY', '1', '25000', 't', 't', NULL),
('ZStepSize', '50', '600000', 't', 't', NULL),
('TimeInterval', '0.001', NULL, 'f', 't', NULL),
('SignalNoiseRatio', '3', '100', 't', 't', NULL),
('NumberOfIterations', '5', '100', 't', 't', NULL),
('QualityChangeStoppingCriterion', '0', NULL, 't', 't', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `file_extension`
-- 

CREATE TABLE `file_extension` (
  `file_format` varchar(30) NOT NULL default '0',
  `extension` varchar(4) NOT NULL default '',
  PRIMARY KEY  (`extension`,`file_format`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='file extensions of the image file formats';

-- 
-- Dumping data for table `file_extension`
-- 

INSERT INTO `file_extension` (`file_format`, `extension`) VALUES ('ics', 'ics'),
('ims', 'ims'),
('lif', 'lif'),
('lsm', 'lsm'),
('lsm-single', 'lsm'),
('ome-xml', 'ome'),
('pic', 'pic'),
('stk', 'stk'),
('tiff', 'tif'),
('tiff-leica', 'tif'),
('tiff-series', 'tif'),
('tiff-single', 'tif'),
('tiff', 'tiff'),
('tiff-leica', 'tiff'),
('tiff-series', 'tiff'),
('tiff-single', 'tiff');

-- --------------------------------------------------------

-- 
-- Table structure for table `file_format`
-- 

CREATE TABLE `file_format` (
  `name` varchar(30) NOT NULL default '0',
  `isFixedGeometry` enum('t','f') NOT NULL default 't',
  `isSingleChannel` enum('t','f') NOT NULL default 't',
  `isVariableChannel` enum('t','f') NOT NULL default 't',
  PRIMARY KEY  (`name`,`isFixedGeometry`,`isSingleChannel`,`isVariableChannel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='stores properties of file formats';

-- 
-- Dumping data for table `file_format`
-- 

INSERT INTO `file_format` (`name`, `isFixedGeometry`, `isSingleChannel`, `isVariableChannel`) VALUES ('ics', 'f', 'f', 't'),
('ims', 'f', 'f', 't'),
('lif', 'f', 'f', 't'),
('lsm', 'f', 'f', 't'),
('lsm-single', 't', 'f', 't'),
('ome-xml', 'f', 'f', 't'),
('pic', 'f', 'f', 't'),
('stk', 'f', 'f', 't'),
('tiff', 'f', 'f', 't'),
('tiff-leica', 'f', 'f', 't'),
('tiff-series', 'f', 'f', 't'),
('tiff-single', 't', 'f', 't');

-- --------------------------------------------------------

-- 
-- Table structure for table `geometry`
-- 

CREATE TABLE `geometry` (
  `name` varchar(30) NOT NULL default '0',
  `isThreeDimensional` enum('t','f') default NULL,
  `isTimeSeries` enum('t','f') default NULL,
  PRIMARY KEY  (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='properties of geometries';

-- 
-- Dumping data for table `geometry`
-- 

INSERT INTO `geometry` (`name`, `isThreeDimensional`, `isTimeSeries`) VALUES ('XYZ', 't', 'f'),
('XYZ - time', 't', 't'),
('XY - time', 'f', 't');

-- --------------------------------------------------------

-- 
-- Table structure for table `job_files`
-- 

CREATE TABLE `job_files` (
  `job` varchar(30) default '0',
  `owner` varchar(30) default '0',
  `file` varchar(255) default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `job_files`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_parameter`
-- 

CREATE TABLE `job_parameter` (
  `owner` varchar(30) NOT NULL default '0',
  `setting` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '0',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`owner`,`setting`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Parameters of a job setting';

-- 
-- Dumping data for table `job_parameter`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_parameter_setting`
-- 

CREATE TABLE `job_parameter_setting` (
  `owner` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `standard` enum('t','f') default 'f',
  PRIMARY KEY  (`name`,`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the parameter settings per job';

-- 
-- Dumping data for table `job_parameter_setting`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_queue`
-- 

CREATE TABLE `job_queue` (
  `id` varchar(30) NOT NULL default '0',
  `user` varchar(30) NOT NULL default '',
  `queued` datetime NOT NULL default '0000-00-00 00:00:00',
  `start` datetime default NULL,
  `stop` datetime default NULL,
  `server` varchar(30) default NULL,
  `process_info` varchar(30) default NULL,
  `status` enum('queued','started','finished','broken','paused') NOT NULL default 'queued',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `user` (`user`),
  KEY `user_status` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='The queue of image processing jobs';

-- 
-- Dumping data for table `job_queue`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_task_parameter`
-- 

CREATE TABLE `job_task_parameter` (
  `owner` varchar(30) NOT NULL default '0',
  `setting` varchar(30) NOT NULL default '',
  `name` varchar(30) NOT NULL default '',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`owner`,`setting`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='task parameter of a job';

-- 
-- Dumping data for table `job_task_parameter`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_task_setting`
-- 

CREATE TABLE `job_task_setting` (
  `owner` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `standard` enum('t','f') default 'f',
  PRIMARY KEY  (`owner`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the task settings per job';

-- 
-- Dumping data for table `job_task_setting`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `parameter`
-- 

CREATE TABLE `parameter` (
  `owner` varchar(30) NOT NULL default '0',
  `setting` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '0',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`owner`,`setting`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Parameters have a value and are part of a user�s setting ';

-- 
-- Dumping data for table `parameter`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `parameter_setting`
-- 

CREATE TABLE `parameter_setting` (
  `owner` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `standard` enum('t','f') default 'f',
  PRIMARY KEY  (`name`,`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the parameter settings per user';

-- 
-- Dumping data for table `parameter_setting`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `possible_values`
-- 

CREATE TABLE `possible_values` (
  `parameter` varchar(30) NOT NULL default '0',
  `value` varchar(255) default NULL,
  `translation` varchar(50) default NULL,
  `isDefault` enum('t','f') default 'f'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='possible values for choice parameter';

-- 
-- Dumping data for table `possible_values`
-- 

INSERT INTO `possible_values` (`parameter`, `value`, `translation`, `isDefault`) VALUES ('IsMultiChannel', 'True', '''''', 'f'),
('IsMultiChannel', 'False', '''''', 'f'),
('ImageFileFormat', 'stk', 'Metamorph (*.stk)', 'f'),
('ImageFileFormat', 'tiff-series', 'Numbered TIFF series (*.tif, *.tiff)', 'f'),
('ImageFileFormat', 'tiff-single', 'TIFF (*.tif, *.tiff) single XY plane', 'f'),
('ImageFileFormat', 'ims', 'Imaris Classic (*.ims)', 'f'),
('ImageFileFormat', 'lsm', 'Zeiss (*.lsm)', 'f'),
('ImageFileFormat', 'lsm-single', 'Zeiss (*.lsm) single XY plane', 'f'),
('ImageFileFormat', 'pic', 'Biorad (*.pic)', 'f'),
('NumberOfChannels', '1', '''''', 'f'),
('NumberOfChannels', '2', '''''', 'f'),
('NumberOfChannels', '3', '''''', 'f'),
('NumberOfChannels', '4', '''''', 'f'),
('ImageGeometry', 'XYZ', '''''', 'f'),
('ImageGeometry', 'XY - time', '''''', 'f'),
('ImageGeometry', 'XYZ - time', '''''', 'f'),
('MicroscopeType', 'widefield', 'widefield', 'f'),
('MicroscopeType', 'multipoint confocal (spinning disk)', 'nipkow', 'f'),
('MicroscopeType', 'single point confocal', 'confocal', 'f'),
('MicroscopeType', 'two photon', 'widefield', 'f'),
('ObjectiveMagnification', '10', '''''', 'f'),
('ObjectiveMagnification', '20', '''''', 'f'),
('ObjectiveMagnification', '25', '''''', 'f'),
('ObjectiveMagnification', '40', '''''', 'f'),
('ObjectiveType', 'oil', '1.515', 'f'),
('ObjectiveType', 'water', '1.3381', 'f'),
('ObjectiveType', 'air', '1.0', 'f'),
('SampleMedium', 'water / buffer', '1.339', 't'),
('SampleMedium', 'liquid vectashield / 90-10 (v:v) glycerol - PBS ph 7.4', '1.47', 'f'),
('Binning', '1', '''''', 'f'),
('Binning', '2', '''''', 'f'),
('Binning', '3', '''''', 'f'),
('Binning', '4', '''''', 'f'),
('Binning', '5', '''''', 'f'),
('MicroscopeName', 'Zeiss 510', '''''', 'f'),
('MicroscopeName', 'Zeiss 410', '''''', 'f'),
('MicroscopeName', 'Zeiss Two Photon 1', '''''', 'f'),
('MicroscopeName', 'Zeiss Two Photon 2', '''''', 'f'),
('MicroscopeName', 'Leica DMRA', '''''', 'f'),
('MicroscopeName', 'Leica DMRB', '''''', 'f'),
('MicroscopeName', 'Leica Two Photon 1', '''''', 'f'),
('MicroscopeName', 'Leica Two Photon 2', '''''', 'f'),
('Resolution', '128', '''''', 'f'),
('Resolution', '256', '''''', 'f'),
('Resolution', '512', '''''', 'f'),
('Resolution', '1024', '''''', 'f'),
('Resolution', '2048', '''''', 'f'),
('RemoveNoiseEffectiveness', '1', '''''', 'f'),
('RemoveNoiseEffectiveness', '2', '''''', 'f'),
('RemoveNoiseEffectiveness', '3', '''''', 'f'),
('OutputFileFormat', 'TIFF 8-bit', 'tiff', 'f'),
('OutputFileFormat', 'TIFF 16-bit', 'tiff16', 'f'),
('OutputFileFormat', 'IMS (Imaris Classic)', 'imaris', 't'),
('OutputFileFormat', 'ICS (Image Cytometry Standard)', 'ics', 'f'),
('ObjectiveMagnification', '63', '''''', 'f'),
('ObjectiveMagnification', '100', '''''', 'f'),
('PointSpreadFunction', 'theoretical', '''''', 'f'),
('PointSpreadFunction', 'measured', '''''', 'f'),
('HasAdaptedValues', 'True', '''''', 'f'),
('HasAdaptedValues', 'False', '''''', 'f'),
('ImageFileFormat', 'ome-xml', 'OME-XML (*.ome)', 'f'),
('ImageFileFormat', 'tiff', 'Olympus TIFF (*.tif, *.tiff))', 'f'),
('ImageFileFormat', 'lif', 'Leica (*.lif)', 'f'),
('ImageFileFormat', 'tiff-leica', 'Leica TIFF series (*.tif, *.tiff)', 'f'),
('ImageFileFormat', 'ics', 'Image Cytometry Standard (*.ics/*.ids)', 'f'),
('ObjectiveType', 'glycerol', '1.4729', 'f'),
('StyleOfProcessing', 'FullRestoration', 'full restoration', 'f'),
('StyleOfProcessing', 'RemoveBackground', 'remove background', 'f');

-- --------------------------------------------------------

-- 
-- Table structure for table `queuemanager`
-- 

CREATE TABLE `queuemanager` (
  `switch` enum('on','off') NOT NULL default 'on'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Table with one field to switch off the queue manager';

-- 
-- Dumping data for table `queuemanager`
-- 

INSERT INTO `queuemanager` (`switch`) VALUES ('on');

-- --------------------------------------------------------

-- 
-- Table structure for table `server`
-- 

CREATE TABLE `server` (
  `name` varchar(60) NOT NULL default '0',
  `huscript_path` varchar(60) NOT NULL default '',
  `status` enum('busy','disconnected','free') default 'free',
  `job` varchar(30) default NULL,
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the huygens server machines and their status';

-- 
-- Dumping data for table `server`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `task_parameter`
-- 

CREATE TABLE `task_parameter` (
  `owner` varchar(30) NOT NULL default '0',
  `setting` varchar(30) NOT NULL default '',
  `name` varchar(30) NOT NULL default '',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`owner`,`setting`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='parameters of the user�s task settings';

-- 
-- Dumping data for table `task_parameter`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `task_setting`
-- 

CREATE TABLE `task_setting` (
  `owner` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `standard` enum('t','f') default 'f',
  PRIMARY KEY  (`owner`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the task settings per user';

-- 
-- Dumping data for table `task_setting`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `name` varchar(30) NOT NULL default '',
  `password` varchar(255) NOT NULL default '',
  `email` varchar(80) NOT NULL default '',
  `research_group` varchar(30) NOT NULL default '',
  `creation_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `last_access_date` timestamp NOT NULL default '0000-00-00 00:00:00',
  `status` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` (`name`, `password`, `email`, `research_group`, `creation_date`, `last_access_date`, `status`) VALUES ('admin', 'e903fece385fd2167780216958310b0d', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'a');
