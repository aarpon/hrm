-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jun 11, 2007 at 01:26 AM
-- Server version: 5.0.26
-- PHP Version: 5.2.0
-- 
-- Database: `hrm_clean`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `boundary_values`
-- 

CREATE TABLE `boundary_values` (
  `parameter` varchar(255) NOT NULL default '0',
  `min` varchar(30) default NULL,
  `max` varchar(30) default NULL,
  `min_included` enum('t','f') default 't',
  `max_included` enum('t','f') default 't',
  `standard` varchar(30) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='boundary values for numerical parameters';

-- 
-- Dumping data for table `boundary_values`
-- 

INSERT INTO `boundary_values` VALUES ('PinholeSize', '0', NULL, 'f', 't', NULL);
INSERT INTO `boundary_values` VALUES ('RemoveBackgroundPercent', '0', '100', 'f', 't', NULL);
INSERT INTO `boundary_values` VALUES ('BackgroundOffsetPercent', '0', '100', 't', 't', NULL);
INSERT INTO `boundary_values` VALUES ('ExcitationWavelength', '0', NULL, 'f', 't', NULL);
INSERT INTO `boundary_values` VALUES ('EmissionWavelength', '0', NULL, 'f', 't', NULL);
INSERT INTO `boundary_values` VALUES ('CMount', '0.4', '1', 't', 't', '1');
INSERT INTO `boundary_values` VALUES ('TubeFactor', '1', '2', 't', 't', '1');
INSERT INTO `boundary_values` VALUES ('CCDCaptorSizeX', '1', '25000', 't', 't', NULL);
INSERT INTO `boundary_values` VALUES ('CCDCaptorSizeY', '1', '25000', 't', 't', NULL);
INSERT INTO `boundary_values` VALUES ('ZStepSize', '50', '600000', 't', 't', NULL);
INSERT INTO `boundary_values` VALUES ('TimeInterval', '0.001', NULL, 'f', 't', NULL);
INSERT INTO `boundary_values` VALUES ('SignalNoiseRatio', '0', '100', 'f', 't', NULL);
INSERT INTO `boundary_values` VALUES ('NumberOfIterations', '1', '100', 't', 't', NULL);
INSERT INTO `boundary_values` VALUES ('QualityChangeStoppingCriterion', '0', NULL, 't', 't', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `file_extension`
-- 

CREATE TABLE `file_extension` (
  `file_format` varchar(30) NOT NULL default '0',
  `extension` varchar(4) NOT NULL default '',
  PRIMARY KEY  (`extension`,`file_format`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='file extensions of the image file formats';

-- 
-- Dumping data for table `file_extension`
-- 

INSERT INTO `file_extension` VALUES ('dv', 'dv');
INSERT INTO `file_extension` VALUES ('ics', 'ics');
INSERT INTO `file_extension` VALUES ('ims', 'ims');
INSERT INTO `file_extension` VALUES ('lif', 'lif');
INSERT INTO `file_extension` VALUES ('lsm', 'lsm');
INSERT INTO `file_extension` VALUES ('lsm-single', 'lsm');
INSERT INTO `file_extension` VALUES ('ome-xml', 'ome');
INSERT INTO `file_extension` VALUES ('pic', 'pic');
INSERT INTO `file_extension` VALUES ('stk', 'stk');
INSERT INTO `file_extension` VALUES ('tiff', 'tif');
INSERT INTO `file_extension` VALUES ('tiff-leica', 'tif');
INSERT INTO `file_extension` VALUES ('tiff-series', 'tif');
INSERT INTO `file_extension` VALUES ('tiff-single', 'tif');
INSERT INTO `file_extension` VALUES ('tiff', 'tiff');
INSERT INTO `file_extension` VALUES ('tiff-leica', 'tiff');
INSERT INTO `file_extension` VALUES ('tiff-series', 'tiff');
INSERT INTO `file_extension` VALUES ('tiff-single', 'tiff');

-- --------------------------------------------------------

-- 
-- Table structure for table `file_format`
-- 

CREATE TABLE `file_format` (
  `name` varchar(30) NOT NULL default '0',
  `isFixedGeometry` enum('t','f') NOT NULL default 't',
  `isSingleChannel` enum('t','f') NOT NULL default 't',
  `isVariableChannel` enum('t','f') NOT NULL default 't',
  PRIMARY KEY  (`name`,`isFixedGeometry`,`isSingleChannel`,`isVariableChannel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='stores properties of file formats';

-- 
-- Dumping data for table `file_format`
-- 

INSERT INTO `file_format` VALUES ('dv', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('ics', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('ims', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('lif', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('lsm', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('lsm-single', 't', 'f', 't');
INSERT INTO `file_format` VALUES ('ome-xml', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('pic', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('stk', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('tiff', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('tiff-leica', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('tiff-series', 'f', 'f', 't');
INSERT INTO `file_format` VALUES ('tiff-single', 't', 'f', 't');

-- --------------------------------------------------------

-- 
-- Table structure for table `geometry`
-- 

CREATE TABLE `geometry` (
  `name` varchar(30) NOT NULL default '0',
  `isThreeDimensional` enum('t','f') default NULL,
  `isTimeSeries` enum('t','f') default NULL,
  PRIMARY KEY  (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='properties of geometries';

-- 
-- Dumping data for table `geometry`
-- 

INSERT INTO `geometry` VALUES ('XYZ', 't', 'f');
INSERT INTO `geometry` VALUES ('XYZ - time', 't', 't');
INSERT INTO `geometry` VALUES ('XY - time', 'f', 't');

-- --------------------------------------------------------

-- 
-- Table structure for table `job_files`
-- 

CREATE TABLE `job_files` (
  `job` varchar(30) default '0',
  `owner` varchar(30) default '0',
  `file` varchar(255) default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `job_files`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_parameter`
-- 

CREATE TABLE `job_parameter` (
  `owner` varchar(30) NOT NULL default '0',
  `setting` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '0',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`owner`,`setting`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Parameters of a job setting';

-- 
-- Dumping data for table `job_parameter`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_parameter_setting`
-- 

CREATE TABLE `job_parameter_setting` (
  `owner` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `standard` enum('t','f') default 'f',
  PRIMARY KEY  (`name`,`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the parameter settings per job';

-- 
-- Dumping data for table `job_parameter_setting`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_queue`
-- 

CREATE TABLE `job_queue` (
  `id` varchar(30) NOT NULL default '0',
  `username` varchar(30) NOT NULL default '',
  `queued` datetime NOT NULL default '0000-00-00 00:00:00',
  `start` datetime default NULL,
  `stop` datetime default NULL,
  `server` varchar(30) default NULL,
  `process_info` varchar(30) default NULL,
  `status` enum('queued','started','finished','broken','paused') NOT NULL default 'queued',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `username` (`username`),
  KEY `user_status` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='The queue of image processing jobs';

-- 
-- Dumping data for table `job_queue`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_task_parameter`
-- 

CREATE TABLE `job_task_parameter` (
  `owner` varchar(30) NOT NULL default '0',
  `setting` varchar(30) NOT NULL default '',
  `name` varchar(30) NOT NULL default '',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`owner`,`setting`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='task parameter of a job';

-- 
-- Dumping data for table `job_task_parameter`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `job_task_setting`
-- 

CREATE TABLE `job_task_setting` (
  `owner` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `standard` enum('t','f') default 'f',
  PRIMARY KEY  (`owner`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the task settings per job';

-- 
-- Dumping data for table `job_task_setting`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `parameter`
-- 

CREATE TABLE `parameter` (
  `owner` varchar(30) NOT NULL default '0',
  `setting` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '0',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`owner`,`setting`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Parameters have a value and are part of a user�s setting ';

-- 
-- Dumping data for table `parameter`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `parameter_setting`
-- 

CREATE TABLE `parameter_setting` (
  `owner` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `standard` enum('t','f') default 'f',
  PRIMARY KEY  (`name`,`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the parameter settings per user';

-- 
-- Dumping data for table `parameter_setting`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `possible_values`
-- 

CREATE TABLE `possible_values` (
  `parameter` varchar(30) NOT NULL default '0',
  `value` varchar(255) default NULL,
  `translation` varchar(50) default NULL,
  `isDefault` enum('t','f') default 'f'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='possible values for choice parameter';

-- 
-- Dumping data for table `possible_values`
-- 

INSERT INTO `possible_values` VALUES ('IsMultiChannel', 'True', '''''', 'f');
INSERT INTO `possible_values` VALUES ('IsMultiChannel', 'False', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'dv', 'Delta Vision (*.dv)', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'stk', 'Metamorph (*.stk)', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'tiff-series', 'Numbered TIFF series (*.tif, *.tiff)', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'tiff-single', 'TIFF (*.tif, *.tiff) single XY plane', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'ims', 'Imaris Classic (*.ims)', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'lsm', 'Zeiss (*.lsm)', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'lsm-single', 'Zeiss (*.lsm) single XY plane', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'pic', 'Biorad (*.pic)', 'f');
INSERT INTO `possible_values` VALUES ('NumberOfChannels', '1', '''''', 'f');
INSERT INTO `possible_values` VALUES ('NumberOfChannels', '2', '''''', 'f');
INSERT INTO `possible_values` VALUES ('NumberOfChannels', '3', '''''', 'f');
INSERT INTO `possible_values` VALUES ('NumberOfChannels', '4', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ImageGeometry', 'XYZ', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ImageGeometry', 'XY - time', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ImageGeometry', 'XYZ - time', '''''', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeType', 'widefield', 'widefield', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeType', 'multipoint confocal (spinning disk)', 'nipkow', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeType', 'single point confocal', 'confocal', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeType', 'two photon', 'widefield', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveMagnification', '10', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveMagnification', '20', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveMagnification', '25', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveMagnification', '40', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveType', 'oil', '1.515', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveType', 'water', '1.3381', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveType', 'air', '1.0', 'f');
INSERT INTO `possible_values` VALUES ('SampleMedium', 'water / buffer', '1.339', 't');
INSERT INTO `possible_values` VALUES ('SampleMedium', 'liquid vectashield / 90-10 (v:v) glycerol - PBS ph 7.4', '1.47', 'f');
INSERT INTO `possible_values` VALUES ('Binning', '1', '''''', 'f');
INSERT INTO `possible_values` VALUES ('Binning', '2', '''''', 'f');
INSERT INTO `possible_values` VALUES ('Binning', '3', '''''', 'f');
INSERT INTO `possible_values` VALUES ('Binning', '4', '''''', 'f');
INSERT INTO `possible_values` VALUES ('Binning', '5', '''''', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeName', 'Zeiss 510', '''''', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeName', 'Zeiss 410', '''''', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeName', 'Zeiss Two Photon 1', '''''', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeName', 'Zeiss Two Photon 2', '''''', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeName', 'Leica DMRA', '''''', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeName', 'Leica DMRB', '''''', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeName', 'Leica Two Photon 1', '''''', 'f');
INSERT INTO `possible_values` VALUES ('MicroscopeName', 'Leica Two Photon 2', '''''', 'f');
INSERT INTO `possible_values` VALUES ('Resolution', '128', '''''', 'f');
INSERT INTO `possible_values` VALUES ('Resolution', '256', '''''', 'f');
INSERT INTO `possible_values` VALUES ('Resolution', '512', '''''', 'f');
INSERT INTO `possible_values` VALUES ('Resolution', '1024', '''''', 'f');
INSERT INTO `possible_values` VALUES ('Resolution', '2048', '''''', 'f');
INSERT INTO `possible_values` VALUES ('RemoveNoiseEffectiveness', '1', '''''', 'f');
INSERT INTO `possible_values` VALUES ('RemoveNoiseEffectiveness', '2', '''''', 'f');
INSERT INTO `possible_values` VALUES ('RemoveNoiseEffectiveness', '3', '''''', 'f');
INSERT INTO `possible_values` VALUES ('OutputFileFormat', 'TIFF 8-bit', 'tiff', 'f');
INSERT INTO `possible_values` VALUES ('OutputFileFormat', 'TIFF 16-bit', 'tiff16', 'f');
INSERT INTO `possible_values` VALUES ('OutputFileFormat', 'IMS (Imaris Classic)', 'imaris', 't');
INSERT INTO `possible_values` VALUES ('OutputFileFormat', 'ICS (Image Cytometry Standard)', 'ics', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveMagnification', '63', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveMagnification', '100', '''''', 'f');
INSERT INTO `possible_values` VALUES ('PointSpreadFunction', 'theoretical', '''''', 'f');
INSERT INTO `possible_values` VALUES ('PointSpreadFunction', 'measured', '''''', 'f');
INSERT INTO `possible_values` VALUES ('HasAdaptedValues', 'True', '''''', 'f');
INSERT INTO `possible_values` VALUES ('HasAdaptedValues', 'False', '''''', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'ome-xml', 'OME-XML (*.ome)', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'tiff', 'Olympus TIFF (*.tif, *.tiff)', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'lif', 'Leica (*.lif)', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'tiff-leica', 'Leica TIFF series (*.tif, *.tiff)', 'f');
INSERT INTO `possible_values` VALUES ('ImageFileFormat', 'ics', 'Image Cytometry Standard (*.ics/*.ids)', 'f');
INSERT INTO `possible_values` VALUES ('ObjectiveType', 'glycerol', '1.4729', 'f');

-- --------------------------------------------------------

-- 
-- Table structure for table `queuemanager`
-- 

CREATE TABLE `queuemanager` (
  `switch` enum('on','off') NOT NULL default 'on'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Table with one field to switch off the queue manager';

-- 
-- Dumping data for table `queuemanager`
-- 

INSERT INTO `queuemanager` VALUES ('on');

-- --------------------------------------------------------

-- 
-- Table structure for table `server`
-- 

CREATE TABLE `server` (
  `name` varchar(60) NOT NULL default '0',
  `huscript_path` varchar(60) NOT NULL default '',
  `status` enum('busy','disconnected','free') default 'free',
  `job` varchar(30) default NULL,
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the huygens server machines and their status';

-- 
-- Dumping data for table `server`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `task_parameter`
-- 

CREATE TABLE `task_parameter` (
  `owner` varchar(30) NOT NULL default '0',
  `setting` varchar(30) NOT NULL default '',
  `name` varchar(30) NOT NULL default '',
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`owner`,`setting`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='parameters of the user�s task settings';

-- 
-- Dumping data for table `task_parameter`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `task_setting`
-- 

CREATE TABLE `task_setting` (
  `owner` varchar(30) NOT NULL default '0',
  `name` varchar(30) NOT NULL default '',
  `standard` enum('t','f') default 'f',
  PRIMARY KEY  (`owner`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='names of the task settings per user';

-- 
-- Dumping data for table `task_setting`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `username`
-- 

CREATE TABLE `username` (
  `name` varchar(30) NOT NULL default '',
  `password` varchar(255) NOT NULL default '',
  `email` varchar(80) NOT NULL default '',
  `research_group` varchar(30) NOT NULL default '',
  `creation_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `last_access_date` timestamp NOT NULL default '0000-00-00 00:00:00',
  `status` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `username`
-- 

INSERT INTO `username` VALUES ('admin', 'e903fece385fd2167780216958310b0d', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'a');
